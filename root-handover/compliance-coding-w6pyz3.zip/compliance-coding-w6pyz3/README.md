# compliance-coding-w6pyz3 package

Stripped source for the FAIS and POPIA compliance document build chain produced in the chat
"compliance-coding-w6pyz3" (July to October 2026). Every client name, person name, FSP number,
registration number, address, website, cloud-drive identifier and reporting period has been
replaced with a bracketed placeholder such as [FSP LEGAL NAME] or [Key Individual 1]. Search for
"[" to find them all before use.

## What is inside

compliance-skill/
  SKILL.md                         How to cite correctly and build in the house style; accuracy
                                   protocol; the build chain; the traps that have bitten.
  references/fais-citation-map.md  The FSCA RE5 qualifying-criteria matrix (14 Jan 2025, v1)
                                   re-keyed by topic: which Act and section governs what. Plus a
                                   separately verified POPIA and PAIA block. Regulator's published
                                   criteria; reusable. Verify against current law before citing.
  references/gcoc-complaints.md    General Code of Conduct Part XI, ss16 to 19, with the s16
                                   defined terms (reportable complaint, upheld, rejected,
                                   compensation payment, goodwill payment) and what a nil
                                   declaration must say. Verified 2 Oct 2026.
  assets/style.css                 Print design system: black masthead, orange rule, badges,
                                   fillable fields, meta strip, authline footer, A4 @page rules.
  assets/fill.py                   PyMuPDF widget injector: places text fields under grey
                                   uppercase captions and in empty narrow table cells. Skips
                                   meta-strip labels and captions under signature rules.
  assets/build.sh                  Render HTML to PDF with headless Chromium, inject fields,
                                   report per-page fill, write a PNG of every page.
  templates/document.html          Starting point carrying the house layout.

forms/
  nil-complaints-return.html                 Nil Complaints Return and Declaration
  complaints-responsibility-schedule.html    Complaints Handling Responsibility Schedule
  tcf-complaints-evidence-map.html           TCF in Complaints Handling, Evidence Map
  popia-paia-addendum.html                   POPIA and PAIA Compliance Addendum

## What is deliberately not inside

- The rendered PDFs. A PDF cannot be stripped reliably; regenerate from the HTML.
- The organogram HTML and PDF. It is a staff chart carrying about 70 employee names and staff
  numbers and cannot be stripped without destroying it.
- The client logo PNG. Replace [LOGO].png with your own.
- The repository memory file (CLAUDE.md). It is client data end to end.
- Any third-party study material. It is copyright and was never in the repository.

## How to rebuild a document

1. Copy compliance-skill/templates/document.html or one of forms/*.html.
2. Replace every bracketed placeholder.
3. Point the stylesheet link at compliance-skill/assets/style.css.
4. Render: /path/to/chrome --headless --disable-gpu --no-sandbox --print-to-pdf=out.pdf \
          --no-pdf-header-footer "file:///abs/path/to/form.html"
5. Fields: python3 compliance-skill/assets/fill.py out.pdf "Final Name.pdf" [table-default]
   Pass "0" as table-default only for a nil return.
6. Look at every rendered page. Widget counts do not show a covered meta strip, a split
   section or a missing field.

Requirements: Python 3, pymupdf, a Chromium or Chrome binary. No other dependencies.
