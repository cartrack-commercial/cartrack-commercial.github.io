#!/bin/bash
# build.sh <form-basename> "<Output Name.pdf>" [table-default]
# Run from anywhere. Expects ../forms/<basename>.html relative to this script's folder,
# or set FORMS_DIR and OUT_DIR. Chromium path: set CHROME, else a sensible default.
HERE="$(cd "$(dirname "$0")" && pwd)"
FORMS_DIR="${FORMS_DIR:-$HERE/../../forms}"
OUT_DIR="${OUT_DIR:-$PWD}"
CHROME="${CHROME:-/opt/pw-browsers/chromium-1194/chrome-linux/chrome}"
"$CHROME" --headless --disable-gpu --no-sandbox --print-to-pdf="$OUT_DIR/_$1.pdf" --no-pdf-header-footer "file://$FORMS_DIR/$1.html" 2>/dev/null
cd "$OUT_DIR" && python3 "$HERE/fill.py" "_$1.pdf" "$2" "$3" 2>&1 | grep widgets
python3 - "$OUT_DIR/$2" "$1" "$OUT_DIR" <<'PY'
import pymupdf as fitz, sys
d=fitz.open(sys.argv[1]); TOP,BOT=34,808
print(f"  pages={d.page_count}")
for i,p in enumerate(d):
    b=[x for x in p.get_text("blocks") if x[4].strip()]
    w=[x.rect.y1 for x in p.widgets()]
    low=max(max((x[3] for x in b),default=0), max(w,default=0))
    gap=BOT-low; flag=" <-- GAP" if gap>90 and i<d.page_count-1 else ""
    print(f"  p{i+1} ends {low:.0f}  gap {gap:.0f}{flag}")
    p.get_pixmap(dpi=78).save(f"{sys.argv[3]}/_v_{sys.argv[2]}_{i+1}.png")
PY
